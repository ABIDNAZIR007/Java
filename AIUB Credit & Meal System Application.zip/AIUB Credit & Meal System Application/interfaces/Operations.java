package interfaces;  // Packaging

import classes.*;
import java.lang.*;
public interface Operations
{
	public void showInfo();
	public int studentChecker(String id);
	public void setStudentCredit(int idx,int credit);
}