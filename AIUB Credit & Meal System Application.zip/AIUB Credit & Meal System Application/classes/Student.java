package classes;
import java.lang.*;

public class Student extends Person   // Inheritance (Parante Class)
{
	private int credit ;
	private double cgpa ;
	private boolean breakfast;
	private boolean lunch; 
	
	public Student ()
	{

	}
	public Student (String name , String id , int credit,boolean breakfast,boolean lunch)
	{
		super (name , id) ;
		this.credit = credit ;
		this.breakfast=breakfast;
		this.lunch=lunch;
		this.cgpa = 0.0 ;
	}
	public void setCredit (int credit)
	{
		this.credit = credit ;
	}
	public void setCgpa (double cgpa )
	{
		this.cgpa = cgpa ;
	}
	public void setBreakfast (boolean breakfast)
	{
		this.breakfast = breakfast ;
	}
	public void setLunch (boolean lunch)
	{
		this.lunch = lunch ;
	}
	
	public int getCredit()
	{
		return this.credit;
	}
	public double getCgpa()
	{
		return this.cgpa;
	}
	public boolean getBreakfast()
	{
		return this.breakfast;
	}
	public boolean getLunch()
	{
		return this.lunch;
	}

	public void showInfo()
	{
		System.out.println();
		System.out.println("Name is : "+getName());
		System.out.println("Id is : "+getId());
		System.out.println("Credit is : "+credit);
		System.out.println("The total amount of credit is : "+(getCredit()*5500) + " Taka");
		System.out.println("Cgpa is : "+cgpa);
		int mealcost=0;
		if(getBreakfast()==true)
		{
			mealcost+=(100*30);
		}
		if(getLunch()==true)
		{
			mealcost+=(150*30);
		}
		System.out.println("The total amount of Meal Cost is : "+mealcost +" Taka");
		System.out.println("The total Cost is : "+((getCredit()*5500)+mealcost) + " Taka");
	}
}