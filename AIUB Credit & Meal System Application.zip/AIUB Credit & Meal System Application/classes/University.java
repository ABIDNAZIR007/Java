package classes;
import java.lang.*;
import interfaces.*;

public class University implements Operations,Operations2   // Interface
{
	private Student students[] = new Student [500] ;   // Association (One to Many)  & Uses of Array


	public void addStudent (Student s)
	{
		for (int i=0 ; i<students.length ; i++)
		{
			if (students[i] == null)
			{
				students[i] = s ;
				break ;
			}
     	}
	}

	public void showInfo()
	{
		for (int i=0 ; i<students.length ; i++)
		{
			if (students[i] != null )
			{
				System.out.println("--------------");
				students[i].showInfo();
				System.out.println(); 
				System.out.println("--------------");
			}
		}
	}

	public int studentChecker(String id)
	{
		for (int i=0 ;i<students.length ; i++)
		{
			if (students[i]!=null)
			{
				if(id.equals(students[i].getId()))
				{
					return i;
				}

			}
		}
		return -1;
	}
	public void setStudentCredit(int idx,int credit)
	{
		int p=students[idx].getCredit();
		p+=credit;
		students[idx].setCredit(p);
	}

	public void setStudentCgpa(int idx,double cgpa)
	{
		students[idx].setCgpa(cgpa);
	}
}