import classes.*;
import interfaces.*;
import java.lang.*;
import java.util.Scanner;

public class Main
{
	public static void main (String [] args)
	{
		University u1 = new University();

		System.out.println("Welcome to AIUB Credit & Meal System Application");

		while (true)
		{
			try       // Exception Handeling 
			{
			int choice;

			System.out.println();
			System.out.println("Here are Some Options for You : ");
			System.out.println();

			System.out.println("-> Choose 1 for add student");
			System.out.println("-> Choose 2 for showing details");
			System.out.println("-> Choose 3 for adding credits");
			System.out.println("-> Choose 4 for your rating and comments");
			System.out.println("-> Choose anything else for exit");
			System.out.println();
			System.out.print("Enter your choice : ");

			Scanner ss = new Scanner(System.in);

			choice = ss.nextInt();
			ss.nextLine();
			if ( choice == 1)
			{
				System.out.println();
				System.out.print("Enter your name : ");
				String name = ss.nextLine();

				System.out.print("Enter your id : ");
				String id = ss.nextLine();
				
				System.out.print("Enter your credit : ");
				int credit = ss.nextInt();

				if (credit>=12 && credit<=16)
				{
					boolean breakfast=false;
					boolean lunch=false;

					System.out.println();
					System.out.println("Here are some meal options for you : ");
					System.out.println();
					System.out.println("-> Choose 1 for olny Breakfast");
					System.out.println("-> Choose 2 for olny Lunch");
					System.out.println("-> Choose 3 for Breakfast and Lunch");
					System.out.println("-> Choose anything else for no meals");
					System.out.println();

					System.out.print("Enter your choice : ");
					int choice2 = ss.nextInt();

					if (choice2 == 1)
					{
						breakfast=true;
					}
					else if (choice2 == 2)
					{
						lunch=true;
					}
					else if (choice2 == 3)
					{
						breakfast=true;
						lunch=true;
					}
					else
					{
						breakfast=false;
						lunch=false;
					}

					Student s1 ;    // Polymorphism
					
					s1 = new Student(name , id , credit , breakfast, lunch);
					u1.addStudent(s1);
					System.out.println();
				}
				else
				{
					System.out.println();
					System.out.println("Credit number is invalid");
					System.out.println();

				}			
			}

			else if(choice==2)
			{
				u1.showInfo();
				System.out.println();
			}

			else if (choice == 3)
			{
				System.out.println();
				System.out.print("Enter your id : ");
				String id = ss.nextLine();
				int idx=u1.studentChecker(id);
				if (idx!=-1)
				{
					System.out.print("Enter the number of credits you want : ");
					int credit = ss.nextInt();
					if (credit>=10 && credit<=23)
					{
						u1.setStudentCredit(idx,credit);
						System.out.print("Enter CGPA Of Previous Semester : ");
						Double cgpa=ss.nextDouble();

						if (cgpa>=2.5 && cgpa<=4.0)
						{
							System.out.println();
							u1.setStudentCgpa(idx,cgpa);
							System.out.println("Your credit is added");
							System.out.println();						
						}
						else 
						{
							System.out.println();
							System.out.println("Your cgpa is below 2.5. We cannot add your credits");
							System.out.println();

						}

					}
					else 
					{
						System.out.println();
						System.out.println("Credit number is invalid");
						System.out.println();
					}
				}
				else
				{
					System.out.println();
					System.out.println("Student id is invalid");
					System.out.println();
				}
			}
			else if (choice == 4)
			{ 
				    System.out.print("Enter your rating out of 10 : ");
				    double rating = ss.nextDouble();

				    if (rating>=0 && rating<=10)
				    {
				    	System.out.println("\nThank for your rating\n");
				    	ss.nextLine();
				    	System.out.print("Enter your comments : ");
				    	String comments = ss.nextLine();
				    	System.out.println();
				    }
				    else 
				    {
				        System.out.println();
				    	System.out.println("Your rating is invalid");
				    	System.out.println();
				    }
			}
			else
			{
				break;
			}
		}
		catch (Exception e)
			{
				System.out.println();
				System.out.println("Exception is : " +e );

				System.out.println();
				System.out.println("Invalid input");
				System.out.println("Please follow the given informations ");
				System.out.println();
			}

		}
		System.out.println();
		System.out.println("You have selected to exit the application. Thank you for using the system");
	} 
}