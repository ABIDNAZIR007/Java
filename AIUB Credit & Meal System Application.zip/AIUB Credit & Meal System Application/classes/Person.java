package classes; 
import java.lang.*;

public abstract class Person  // Abastraction & Inheritance (Parante Class)
{
	private String name ;
	private String id ;

	public Person ()
	{

	}
	public Person (String name , String id)
	{
		this.name = name ;
		this.id = id ; 
	}

	public void setName (String name)
	{
		this.name = name ;
	}
	public void setId (String id)
	{
		this.id = id ;
	}
	
	public String getName()
	{
		return this.name;
	}
	public String getId()
	{
		return this.id;
	}

	public abstract void showInfo(); // Abstract Methood
}