package interfaces;

import classes.*;
import java.lang.*;

public interface Operations2
{
	public void setStudentCgpa(int idx,double cgpa);
}